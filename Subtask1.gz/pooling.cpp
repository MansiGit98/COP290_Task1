#include <fstream>
#include <iostream>
using namespace std;

class Pooling
{
private:
    float max_pool(float x[], int size)
    {
        float max = x[0];
        for (int i = 0; i < size; i++)
        {
            if (x[i] > max)
                max = x[i];
        }
        return max;
    }
    float avg_pool(float x[], int size)
    {
        float sum = 0;
        for (int i = 0; i < size; i++)
            sum += x[i];
        return sum / size;
    }

public:
    string inputFile;
    string outputFile;
    string type;
    int int_stride;

    void runFunction()
    {
        if (type.compare("max") != 0 && type.compare("average") != 0)
        {
            cout << "Function name is not correct" << endl;
            return;
        }

        bool flag = 0;
        if (type.compare("max") == 0)
            flag = 1;

        ifstream matrix;
        matrix.open(inputFile);

        if (!matrix)
        { // Check if inputs files opened successfully
            cerr << "Error: Input file could not be opened" << endl;
            exit(1);
        }
        int col, row;
        string str;

        getline(matrix, str);
        col = stoi(str);
        getline(matrix, str);
        row = stoi(str);

        if (col != row)
        {
            cout << "Error: Input matrix is not Square...no. of rows and columns must be equal" << endl;
            return;
        }
        if (row % int_stride != 0)
        {
            cout << "Error: Row or column length is not multiple of given Stride" << endl;
            return;
        }

        const int stride = int_stride;
        const int dim = row / stride;

        fstream file;
        file.open(outputFile, ios::out);

        if (!file)
        { // Check if output file created successfully
            cout << "Error in creating file";
            exit(1);
        }

        file << dim << endl;
        file << dim << endl;

        float store[stride * stride];
        float inp_arr[row * col];

        int c, r;
        c = r = 0;
        while (c < col)
        {
            getline(matrix, str);
            inp_arr[r + c * row] = stof(str);
            ++r;
            if (r == row)
            {
                r = 0;
                ++c;
            }
        }

        int rc, cc, x;
        c = r = 0;
        float val;
        while (c < dim)
        {
            cc = c * stride;
            rc = r * stride;
            x = 0;
            for (int m = cc; m < cc + stride; m++)
            {
                for (int n = rc; n < rc + stride; n++)
                {
                    store[x] = inp_arr[n + m * row];
                    ++x;
                }
            }
            if (flag)
                val = max_pool(store, stride * stride);
            else
                val = avg_pool(store, stride * stride);
            file << val << endl;
            ++r;
            if (r == dim)
            {
                r = 0;
                ++c;
            }
        }
        matrix.close();
        file.close();
        return;
    }
};
