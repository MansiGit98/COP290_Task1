#include <fstream>
#include <iostream>
#include <math.h>
using namespace std;

class Probability
{
private:
    float sigmoid_fun(float x)
    {
        float y = exp(-x);
        y = y + 1;
        x = 1 / y;
        return x;
    }
    float softmax_fun(float x, float sum)
    {
        return exp(x) / sum;
    }

public:
    string inputFile;
    string outputFile;
    string type;

    void runFunction()
    {
        if (type.compare("sigmoid") != 0 && type.compare("softmax") != 0)
        {
            cout << "Function name is not correct" << endl;
            return;
        }

        bool flag = 0;
        if (type.compare("softmax") == 0)
            flag = 1;

        ifstream matrix;
        matrix.open(inputFile);

        if (!matrix)
        {
            cerr << "Error: Input matrix file could not be opened" << endl;
            exit(1);
        }

        fstream file;
        file.open(outputFile, ios::out);

        if (!file)
        {
            cerr << "Error in creating file" << endl;
            exit(1);
        }

        string str;
        int size;
        getline(matrix, str);
        size = stoi(str);
        file << size << endl;

        float x, sum = 0.0;
        float arr[size];              // array to store elements of matrix

        for (int r = 0; r < size; r++)
        {
            getline(matrix, str);
            arr[r] = stof(str);               // Storing float values given in input
        }

        if (flag)
            for (int r = 0; r < size; r++)
                sum += exp(arr[r]);                     // Calculate sum if function is softmax

        for (int c = 0; c < size; c++)
        {
            if (flag)
                arr[c] = softmax_fun(arr[c], sum);
            else 
                arr[c] = sigmoid_fun(arr[c]);
            file << arr[c] << endl;
        }
        matrix.close();
        file.close();
        return;
    }
};

