# Project Name-
    COP290
    Task1: Create a small audio processing library 
    Subtask1: Warming up to compiling and debugging some C++ functions

# Installation-
    C++ compiler
    Ubuntu linux operating system

# Folder Description -

## Folder name - 2020CS10357.tar.gz

Files in this folder -
1. CPP (.cpp) files - 
MainFile.cpp
fullyconnected.cpp
activation.cpp
pooling.cpp
probability.cpp

This files contain c++ programs. Four of them are c++ class files for implementing functions according to there name and one file whose name is MainFile.cpp contain main() function so that program start executing from here.

2. Makefile - This file contain two commands.
Type $make on terminal to compile all .cpp files and finally output a executable file named yourcode.out

# Way of Invoking functions-
./yourcode.out fullyconnected inputmatrix.txt weightmatrix.txt biasmatrix.txt outputmatrix.txt 

./yourcode.out activation relu inputmatrix.txt outputmatrix.txt 

./yourcode.out activation tanh inputmatrix.txt outputmatrix.txt 

./yourcode.out pooling max inputmatrix.txt stride outputmatrix.txt 

./yourcode.out pooling average inputmatrix.txt stride outputmatrix.txt 

./yourcode.out probability softmax inputvector.txt outputvector.txt 

./yourcode.out probability sigmoid inputvector.txt outputvector.txt 


# My Info
Name - Mansi
Entry Number - 2020CS10357
