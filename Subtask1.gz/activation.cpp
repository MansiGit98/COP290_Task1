#include <fstream>
#include <iostream>
#include <math.h>
using namespace std;

class Activation
{
private:
   float relu_fun(float x)
   {
      if (x < 0)
         x = 0;
      return x;
   }
   float tanh_fun(float x)
   {
      float y = exp(2 * x);
      x = (y - 1) / (y + 1);
      return x;
   }

public:
   string inputFile;
   string outputFile;
   string type;

   void runFunction()
   {
      if (type.compare("relu") != 0 && type.compare("tanh") != 0)
      {
         cout << "Error: Function name is not correct" << endl;
         return;
      }

      bool flag = 0;
      if (type.compare("relu") == 0)
         flag = 1;

      ifstream matrix;
      matrix.open(inputFile); // Opening input files

      if (!matrix)
      { // Check if inputs files opened successfully
         cerr << "Error: file could not be opened" << endl;
         exit(1);
      }

      fstream result;
      result.open(outputFile, ios::out);

      if (!result)
      { // Check if output file created successfully
         cout << "Error in creating file";
         exit(1);
      }

      string str;
      int col, row;
      getline(matrix, str);
      col = stoi(str);
      getline(matrix, str);
      row = stoi(str);

      result << col << endl;
      result << row << endl;
      float x;
      if (flag)                                    // If function is relu
         for (int c = 0; c < col; c++)
            for (int r = 0; r < row; r++)
            {
               getline(matrix, str);
               x = stof(str);
               x = relu_fun(x);
               result << x << endl;
            }
      else                                         // If function is tanh
         for (int c = 0; c < col; c++)
            for (int r = 0; r < row; r++)
            {
               getline(matrix, str);
               x = stof(str);
               x = tanh_fun(x);
               result << x << endl;
            }

      matrix.close(); // Closing files
      result.close();
      return;
   }
};

