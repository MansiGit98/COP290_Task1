#include <iostream>
#include "fullyconnected.cpp"
#include "activation.cpp"
#include "pooling.cpp"
#include "probability.cpp"
using namespace std;

int main(int argc, char *argv[])
{
    string str = argv[1];
    if (str.compare("fullyconnected") == 0)
    {
        if (argc != 6)
        {
            cout << "Error: Command is not typed correctly" << endl;
            return 0;
        }
        FullyConnected obj;
        obj.inputFile = argv[2];
        obj.weightFile = argv[3];
        obj.biasFile = argv[4];
        obj.outputFile = argv[5];
        obj.runFunction();
    }
    else if (str.compare("activation") == 0)
    {
        if (argc != 5)
        {
            cout << "Error: Command is not typed correctly" << endl;
            return 0;
        }
        Activation obj;
        obj.type = argv[2];
        obj.inputFile = argv[3];
        obj.outputFile = argv[4];
        obj.runFunction();
    }
    else if (str.compare("pooling") == 0)
    {
        if (argc != 6)
        {
            cout << "Error: Command is not typed correctly" << endl;
            return 0;
        }
        Pooling obj;
        obj.type = argv[2];
        obj.inputFile = argv[3];
        try
        {
            obj.int_stride = stoi(argv[4]);
        }
        catch (exception &err)
        {
            cout << "Argument not valid...Stride must be integer" << endl;
            return 0;
        }

        obj.outputFile = argv[5];
        obj.runFunction();
    }
    else if (str.compare("probability") == 0)
    {
        if (argc != 5)
        {
            cout << "Error: Command is not typed correctly" << endl;
            return 0;
        }
        Probability obj;
        obj.type = argv[2];
        obj.inputFile = argv[3];
        obj.outputFile = argv[4];
        obj.runFunction();
    }
    else
        cout << "Error: Name of function is not recognized" << endl;

    return 0;
}
