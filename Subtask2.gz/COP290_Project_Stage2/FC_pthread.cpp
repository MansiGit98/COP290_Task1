#include <iostream>
#include <fstream>
#include <chrono>
#include <pthread.h>
#include <bits/stdc++.h>
using namespace std;
using namespace std::chrono;

float matrixA[1000][1000];
float matrixB[1000][1000];
float matrixR[1000][1000];

struct arg_data
{
	int rline; // row line
	int rowA;
	int colA;
	int rowB;
	int colB;
};

static void *matrixMul(void *args)
{
	struct arg_data *my_data;
	my_data = (struct arg_data *)args;
	int l, rA, cA, rB, cB;
	l = my_data->rline;
	rA = my_data->rowA;
	cA = my_data->colA;
	rB = my_data->rowB;
	cB = my_data->colB;

	for (int j = 0; j < cB; j++)
	{
		matrixR[l][j] = 0.0;
		for (int k = 0; k < cA; k++)
		{
			matrixR[l][j] += matrixA[l][k] * matrixB[k][j];
		}
	}
	pthread_exit(NULL);
}

void matrixSum(int r, int c)
{
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			matrixR[i][j] = matrixA[i][j] + matrixR[i][j];
		}
	}
}

int Calu_Mean(int time[], int a){                   //Calculate Mean
	int sum = 0;
	for(int i=0; i < a; ++i){
		sum += time[i];
	}
	sum = sum/a;
	return sum;
}

int Calu_stdDev(int time[], int a, int mean){      //Calculate Standard Deviation
	int store, sum = 0;
	for(int i=0; i < a; ++i){
		sum += pow(time[i] - mean, 2);
	}
	sum = sqrt(sum / a);
	return sum;
}


int main(int argc, char *argv[])
{
	string str1 = argv[1];
	string str2 = argv[2];
	string inputFile;
	string weightFile;
	string biasFile;
	string outputFile;

	if (str1.compare("fullyconnected") == 0 && str2.compare("pthread") == 0)
	{
		if (argc != 7)
		{
			cout << "Command is not typed correctly" << endl;
			return 0;
		}
		inputFile = argv[3];
		weightFile = argv[4];
		biasFile = argv[5];
		outputFile = argv[6];
	}
	else
	{
		cout << "Name of function is not recognized" << endl;
		return 0;
	}

	ifstream matrix;
	matrix.open(inputFile);

	if (!matrix)
	{ // file couldn't be opened
		cerr << "Error: Input matrix file could not be opened" << endl;
		exit(1);
	}

	string str;
	int col1, row1;
	getline(matrix, str);
	col1 = stoi(str);
	getline(matrix, str);
	row1 = stoi(str);

	for (int c = 0; c < col1; c++)
	{
		for (int r = 0; r < row1; r++)
		{
			getline(matrix, str);
			matrixA[r][c] = stof(str);
		}
	}

	matrix.close();

	int col2, row2;

	matrix.open(weightFile);

	if (!matrix)
	{ // file couldn't be opened
		cerr << "Error: Weight matrix file could not be opened" << endl;
		exit(1);
	}
	getline(matrix, str);
	col2 = stoi(str);
	getline(matrix, str);
	row2 = stoi(str);

	for (int c = 0; c < col2; c++)
	{
		for (int r = 0; r < row2; r++)
		{
			getline(matrix, str);
			matrixB[r][c] = stof(str);
		}
	}

	matrix.close();

	if (col1 != row2)
	{
		cout << "Dimensions of Input matices are inappropriate." << endl;
		return 0;
	}

	struct arg_data td[row1];

	pthread_t threadID[row1];
	int runtime[5];
	
	for (int x = 0; x < 5; x++)
       {
       	auto start = high_resolution_clock::now();

      		for (int i = 0; i < row1; i++)
      		{
        		td[i].rline = i;
        		td[i].rowA = row1;
        		td[i].colA = col1;
        		td[i].rowB = row2;
        		td[i].colB = col2;

        		threadID[i] = i;
        		pthread_create(&threadID[i], NULL, matrixMul, &td[i]);
      		}

      		for (int i = 0; i < row1; i++)
      		{
        		pthread_join(threadID[i], NULL);
      		}

      		auto stop = high_resolution_clock::now();
      		auto duration = duration_cast<microseconds>(stop - start);
      		runtime[x] = duration.count();
    	}
    
        int mean = Calu_Mean(runtime, 5);
        int SD = Calu_stdDev(runtime, 5, mean);
        cout << "Mean is: " << mean << " microseconds" << endl;
        cout << "Standard deviation is: " << SD << " microseconds" << endl;


	matrix.open(biasFile);

	if (!matrix)
	{ // file couldn't be opened
		cerr << "Error: Bias matrix file could not be opened" << endl;
		exit(1);
	}

	int col3, row3;

	getline(matrix, str);
	col3 = stoi(str);
	getline(matrix, str);
	row3 = stoi(str);

	if (col3 != col2 || row3 != row1)
	{
		cout << "Dimensions of Input matices are inappropriate." << endl;
		return 0;
	}

	for (int c = 0; c < col3; c++)
	{
		for (int r = 0; r < row3; r++)
		{
			getline(matrix, str);
			matrixA[r][c] = stof(str);
		}
	}
	matrix.close();

	matrixSum(row1, col2);

	fstream file;
	file.open(outputFile, ios::out);
	if (!file)
	{
		cerr << "Error in creating file!!!" << endl;
		exit(1);
	}

	file << row1 << endl;
	file << col2 << endl;

	for (int i = 0; i < col2; i++)
	{
		for (int j = 0; j < row1; j++)
		{
			file << matrixR[j][i] << endl;
		}
	}
	file.close();
 	return 0;
}

