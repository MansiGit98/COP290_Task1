# Project Name-
    COP290
    Task1: Create a small audio processing library 
    Subtask2: Code performance, learning plotting through scripts

# Installation-
    C++ compiler
    Ubuntu linux operating system
    OpenBlas Library
    MKL Library
    Gnupolt

# Folder Description -

## Folder name - 2020CS10357.tar.gz

Files in this folder -
1. CPP (.cpp) files - 
FC_pthread.cpp
FC_openbals.cpp
FC_normal.cpp
FC_mkl.cpp

This files contain c++ programs. All of them are c++ files containing main() for implementing functions according to there name. Each function calulate runtime of multiplication of matrix part five time and then calculate mean and standard deviation of this runtimes to give more accurate values.

2. Makefile - This file contain four commands.
Type ($make pthread) for compling program containing pthread implementation.
Type ($make openblas) for compling program containing openblash implementation.
Type ($make mkl) for compling program containing mkl implementation.
Type ($make normal) for compling program containing normal implementation.

In all case, (yourcode.out) executable file created.

# Way of Invoking functions-
./yourcode.out fullyconnected pthread inputmatrix.txt weightmatrix.txt biasmatrix.txt outputmatrix.txt 

./yourcode.out fullyconnected openblas inputmatrix.txt weightmatrix.txt biasmatrix.txt outputmatrix.txt 

./yourcode.out fullyconnected mkl inputmatrix.txt weightmatrix.txt biasmatrix.txt outputmatrix.txt 

./yourcode.out fullyconnected normal inputmatrix.txt weightmatrix.txt biasmatrix.txt outputmatrix.txt 


3. Gnuplot - This folder has-

Latency.dat - this file contain row-wise data as:
Row 1 - Dimension of matrix. For value let say N, the input matrix, output matrix and bais matrix all hava dimension NxN. 
Row 2 - Mean value of Openblas implementation.
Row 3 - Mean value of pthread implementation.
Row 4 - Mean value of normal implementation.


Pthread.dat - this file contain row-wise data as:
Row 1 - Dimension of matrix. For value let say N, the input matrix, output matrix and bais matrix all hava dimension NxN. 
Row 2 - Mean value of pthread implementation.
Row 3 - Standard Deviation value of pthread implementation.


OpenBlas.dat
Row 1 - Dimension of matrix. For value let say N, the input matrix, output matrix and bais matrix all hava dimension NxN. 
Row 2 - Mean value of OpenBlas implementation.
Row 3 - Standard Deviation value of OpenBlas implementation.


Normal.dat
Row 1 - Dimension of matrix. For value let say N, the input matrix, output matrix and bais matrix all hava dimension NxN. 
Row 2 - Mean value of Normal implementation.
Row 3 - Standard Deviation value of Normal implementation.

We choose such square dimensions for demonstration purpose. But our program will be able to compute for any valid dimensions.

Latency.pdf - This contain latency plot for pthread, openblas, normal.

Pthread.pdf - This contain line plot for mean and errorbars of standard deviation of Pthread.

OpenBlas.pdf - This contain line plot for mean and errorbars of standard deviation of OpenBlas.

Normal.pdf - This contain line plot for mean and errorbars of standard deviation of Normal.

# My Info
Group member -

Sheetal Kanel 
Entry Number - 2020CS10381

Mansi
Entry Number - 2020CS10357




