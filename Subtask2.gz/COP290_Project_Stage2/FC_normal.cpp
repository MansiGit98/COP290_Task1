#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
#include <chrono>
using namespace std;
using namespace std::chrono;

void matrixMul(int r1, int c1, int r2, int c2, float mtx1[], float mtx2[], float mtxr[])
    {
        int i, j, k;
        for (i = 0; i < r1; i++)
        {
            for (j = 0; j < c2; j++)
            {
                mtxr[i + r1 * j] = 0;
                for (k = 0; k < c1; k++)
                {
                    mtxr[i + r1 * j] += mtx1[i + k * r1] * mtx2[k + j * r2];
                }
            }
        }
    }

void matrixSum(int r, int c, float mtxi[], float mtxr[], float mtxo[])
    {
        for (int i = 0; i < r; i++)
        {
            for (int j = 0; j < c; j++)
            {
                mtxo[i + j * r] = mtxi[i + j * r] + mtxr[i + j * r];
            }
        }
    }


int Calu_Mean(int time[], int a){                   //Calculate Mean
	int sum = 0;
	for(int i=0; i < a; ++i){
		sum += time[i];
	}
	sum = sum/a;
	return sum;
}

int Calu_stdDev(int time[], int a, int mean){      //Calculate Standard Deviation
	int store, sum = 0;
	for(int i=0; i < a; ++i){
		sum += pow(time[i] - mean, 2);
	}
	sum = sqrt(sum / a);
	return sum;
}


int main(int argc, char *argv[])
{
	string str1 = argv[1];
	string str2 = argv[2];
	string inputFile;
	string weightFile;
	string biasFile;
	string outputFile;

	if (str1.compare("fullyconnected") == 0 && str2.compare("normal") == 0)
	{
		if (argc != 7)
		{
			cout << "Command is not typed correctly" << endl;
			return 0;
		}
		inputFile = argv[3];
		weightFile = argv[4];
		biasFile = argv[5];
		outputFile = argv[6];
	}
	else
	{
		cout << "Name of function is not recognized" << endl;
		return 0;
	}

	ifstream matrix;
        matrix.open(inputFile);

        if (!matrix)
        { // file couldn't be opened
            cerr << "Error: Input matrix file could not be opened" << endl;
            exit(1);
        }

        string str;
        int col1, row1;
        getline(matrix, str);
        col1 = stoi(str);
        getline(matrix, str);
        row1 = stoi(str);

        float input_array[row1 * col1];

        for (int c = 0; c < col1; c++)
        {
            for (int r = 0; r < row1; r++)
            {
                getline(matrix, str);
                input_array[c * row1 + r] = stof(str);
            }
        }

        matrix.close();

        int col2, row2;

        matrix.open(weightFile);

        if (!matrix)
        { // file couldn't be opened
            cerr << "Error: Weight matrix file could not be opened" << endl;
            exit(1);
        }
        getline(matrix, str);
        col2 = stoi(str);
        getline(matrix, str);
        row2 = stoi(str);

        float weight_array[row2 * col2];

        for (int c = 0; c < col2; c++)
        {
            for (int r = 0; r < row2; r++)
            {
                getline(matrix, str);
                weight_array[c * row2 + r] = stof(str);
            }
        }

        matrix.close();

        matrix.open(biasFile);

        if (!matrix)
        { // file couldn't be opened
            cerr << "Error: Bias matrix file could not be opened" << endl;
            exit(1);
        }

        int col3, row3;

        getline(matrix, str);
        col3 = stoi(str);
        getline(matrix, str);
        row3 = stoi(str);

        float bias_array[row3 * col3];

        for (int c = 0; c < col3; c++)
        {
            for (int r = 0; r < row3; r++)
            {
                getline(matrix, str);
                bias_array[c * row3 + r] = stof(str);
            }
        }
        matrix.close();

        if(col1 != row2 || col3 != col2 || row3 != row1){
            cout << "Dimensions of Input matices are inappropriate." << endl;
            return 0;
        }

        float output_array[row1 * col2];

	int runtime[5];
	for(int x = 0; x < 5; x++){
		auto start = high_resolution_clock::now();
	
	  	matrixMul(row1, col1, row2, col2, input_array, weight_array, output_array);
	
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<microseconds>(stop - start);
		runtime[x] = duration.count();
	}
	
	int mean = Calu_Mean(runtime, 5);
        int SD = Calu_stdDev(runtime, 5, mean);
        cout << "Mean is: " << mean << " microseconds" << endl;
        cout << "Standard deviation is: " << SD << " microseconds" << endl;
        
        matrixSum(row1, col2, output_array, bias_array, output_array);

        fstream file;
        file.open(outputFile, ios::out);
        if (!file)
        {
            cerr << "Error in creating file!!!" << endl;
            exit(1);
        }

        file << row1 << endl;
        file << col2 << endl;

        for (int i = 0; i < col2; i++)
        {
            for (int j = 0; j < row1; j++)
            {
                file << output_array[j + i * row1] << endl;
            }
        }
        file.close();
 	return 0;
}
