#include <iostream>
#include <fstream>
#include <string>
#include "audio.hpp"
#include<cblas.h>
using namespace std;
#define TRANSPOSE(X) ((X) ? CblasTrans : CblasNoTrans)
void matrixMul(int r1, int c1, int r2, int c2, float *mtx1, float *mtx2, float *mtxr,bool tA,bool tB,float beta)
    {
        int lda = tA ? r1 : c1;
        int ldb = tB ? c1 : c2;
        cblas_sgemm(CblasRowMajor,TRANSPOSE(tA), TRANSPOSE(tB), r1, c2, c1, 1.0, mtx1, lda,mtx2, ldb,beta, mtxr, c2);  
    }


void matrixSum(int r, int c, float *mtxi, float *mtxr, float *mtxo)
{
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            mtxo[i + j * r] = mtxi[i + j * r] + mtxr[i + j * r];
}
// t1, t2, t3 For dimension of Input, Weight and Bias Matrix

void runFC(string inputFile, string weightFile, string biasFile, string outputFile, int t1, int t2, int t3)
{
    ifstream matrix;
    matrix.open(inputFile);

    if (!matrix)
    { // file couldn't be opened
        cerr << "Error: Input matrix file could not be opened" << endl;
        exit(1);
    }

    string str;
    int row1 = t1;
    int col1 = t2;
    int row2 = t2;
    int col2 = t3;

    float *input_array= new float[row1 * col1];

    for (int c = 0; c < col1; c++)
        for (int r = 0; r < row1; r++)
        {
            getline(matrix, str);
            input_array[c * row1 + r] = stof(str);
            // cout << "..............Mark  "<< r << " " << c << endl;
        }
    matrix.close();

    matrix.open(weightFile);

    if (!matrix)
    { // file couldn't be opened
        cerr << "Error: Weight matrix file could not be opened" << endl;
        exit(1);
    }

    float *weight_array= new float[row2 * col2];

    for (int c = 0; c < col2; c++)
        for (int r = 0; r < row2; r++)
        {
            getline(matrix, str);
            weight_array[c * row2 + r] = stof(str);
        }
    matrix.close();

    matrix.open(biasFile);

    if (!matrix)
    { // file couldn't be opened
        cerr << "Error: Bias matrix file could not be opened" << endl;
        exit(1);
    }

    float *bias_array= new float[row1 * col2];
    for (int c = 0; c < col2; c++)
        for (int r = 0; r < row1; r++)
        {
            getline(matrix, str);
            bias_array[c * row1 + r] = stof(str);
        }
    matrix.close();

    float* output_array = new float[row1 * col2];

    matrixMul(row1, col1, row2, col2, input_array, weight_array, output_array,false,false,0.0);
    matrixSum(row1, col2, output_array, bias_array, output_array);

    fstream file;
    file.open(outputFile, ios::out);
    if (!file)
    {
        cerr << "Error in creating file!!!" << endl;
        exit(1);
    }

    for (int i = 0; i < col2; i++)
        for (int j = 0; j < row1; j++)
            file << output_array[j + i * row1] << endl;

    file.close();
    return;
}
