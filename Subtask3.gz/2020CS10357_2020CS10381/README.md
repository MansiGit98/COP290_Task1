# Project Name-
    COP290
    Task1: Create a small audio processing library 
    Subtask3:  Hierarchical code design, creating library and API

# Installation-
    C++ compiler
    Ubuntu linux operating system
    OpenBlas Library

# Folder Description -

## Folder name - 2020CS10357_2020CS10381.tar.gz

Files in this folder -

## 1. CPP (.cpp) files - 
### FC_openbals.cpp
### main.cpp
### Relu.cpp
### Runner.cpp
### Softmax.cpp

main.cpp file contain code for audio processing using library.

## 2. HPP(.hpp) file -
### audio.hpp

This is header file that is included in main file for using audio processing library. These contains all audio processing functions. 

## 3. Library(.so) file -
### libaudio.so
This is library that we created for Audio processing.

## 4. Makefile - This file contain few commands.
Type ($make ) for creating library, compling program and creating final executable file named yourcode.out 

# Way of Invoking functions-
./yourcode.out inputfile.txt outfile.txt 

# My Info
Group member -

Mansi
Entry Number - 2020CS10357

Sheetal Kanel 
Entry Number - 2020CS10381




