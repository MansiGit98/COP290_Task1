#ifndef AUDIO_H
#define AUDIO_H
using namespace std;


typedef struct{
    int label;
    float prob;
}pred_t;

extern void runRELU(string inputFile, string outputFile, int row, int col);
extern void runSOFTMAX(string inputFile, string outputFile, int size);
extern void matrixMul(int r1, int c1, int r2, int c2, float* mtx1, float* mtx2, float* mtxr);
extern void matrixSum(int r, int c, float* mtxi, float* mtxr, float* mtxo);
extern void runFC(string inputFile, string weightFile, string biasFile, string outputFile, int t1, int t2, int t3);
extern pred_t* libaudioAPI(const char *audiofeatures, pred_t *pred);

#endif

