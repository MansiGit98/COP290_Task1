#include <fstream>
#include <iostream>
#include "audio.hpp"
using namespace std;

void runRELU(string inputFile, string outputFile, int row, int col)
{
    ifstream matrix;
    matrix.open(inputFile); // Opening input file

    if (!matrix)
    { // Check if inputs files opened successfully
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }

    fstream result;
    result.open(outputFile, ios::out);

    if (!result)
    { // Check if output file created successfully
        cout << "Error in creating file";
        exit(1);
    }

    string str;
    float x;

    for (int c = 0; c < col; c++)
        for (int r = 0; r < row; r++)
        {
            getline(matrix, str);
            x = stof(str);
            if (x < 0)
                x = 0; // Relu function
            result << x << endl;
        }
    matrix.close(); // Closing files
    result.close();
    return;
}

