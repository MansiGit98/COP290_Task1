#include <fstream>
#include <iostream>
#include "audio.hpp"

using namespace std;

int main(int argc, char *argv[]){
    if (argc != 3)
        {
            cout << "Error: Command is not typed correctly" << endl;
            return 0;
        }

    const char* InputTxt = argv[1];
    
    pred_t pred[3];
    for(int i=0; i < 3; ++i){
        pred[i].label = 0;
        pred[i].prob = 0.0;
    }

    pred_t* ptr = libaudioAPI(InputTxt, pred);

    string str[12];
    str[0] = "silence";
    str[1] = "unknown";
    str[2] = "yes";
    str[3] = "no";
    str[4] = "up";
    str[5] = "down";
    str[6] = "left";
    str[7] = "right";
    str[8] = "on";
    str[9] = "off";
    str[10] = "stop";
    str[11] = "go";
    
    ofstream fout;
    string stri = argv[2];
    fout.open(stri, ios::app);
    if (!fout)
    { // Check if output file created successfully
        cout << "Error in creating output file";
        exit(1);
    }
    fout <<"\n"<< InputTxt;
    for(int i=0; i < 3; ++i){
       fout <<" "<< str[ptr[i].label-1];
    }
    for(int i=0;i<3;++i){
       fout<<" "<< ptr[i].prob;
    }


    fout.close();
    return 0; 

}
