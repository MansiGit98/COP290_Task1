#include <fstream>
#include <iostream>
#include "audio.hpp"
using namespace std;

pred_t* libaudioAPI(const char *audiofeatures, pred_t *pred)
{
    string InputTxt = audiofeatures; // This is audio file with 250 float points
    fstream file;
    file.open(InputTxt.c_str());

    fstream result;
    result.open("FC_Dummy2.txt", ios::out);

    if (!result)
    { // Check if output file created successfully
        cout << "Error in creating file";
        exit(1);
    }

    int cnt = 0;
    string data = "";

    while (file >> data)
    {
        result << data << endl;
        ++cnt;
    }

    file.close();
    result.close();
    
    if(cnt != 250){
    	cout << "Error: Audio file must have 250 float values" << endl;
    	exit(1);
    }

    runFC("FC_Dummy2.txt", "IP1_WT.txt", "IP1_BIAS.txt", "FC_Dummy1.txt", 1, 250, 144);
    runRELU("FC_Dummy1.txt", "FC_Dummy2.txt", 1, 144);

    runFC("FC_Dummy2.txt", "IP2_WT.txt", "IP2_BIAS.txt", "FC_Dummy1.txt", 1, 144, 144);
    runRELU("FC_Dummy1.txt", "FC_Dummy2.txt", 1, 144);

    runFC("FC_Dummy2.txt", "IP3_WT.txt", "IP3_BIAS.txt", "FC_Dummy1.txt", 1, 144, 144);
    runRELU("FC_Dummy1.txt", "FC_Dummy2.txt", 1, 144);

    runFC("FC_Dummy2.txt", "IP4_WT.txt", "IP4_BIAS.txt", "FC_Dummy1.txt", 1, 144, 12);
    runSOFTMAX("FC_Dummy1.txt", "FC_Dummy2.txt", 12);

    ifstream output;
    output.open("FC_Dummy2.txt"); // Opening input file

    if (!output)
    { // Check if inputs files opened successfully
        cerr << "Error: file could not be opened" << endl;
        exit(1);
    }

    string str;
    float x;

    for (int i = 0; i < 12; ++i)
    {
        getline(output, str);
        x = stof(str);
        if (x > pred[2].prob)
        {
            pred[2].prob = x;
            pred[2].label = i + 1;

            if (x > pred[1].prob)
            {
                pred[2].prob = pred[1].prob;
                pred[2].label = pred[1].label;
                pred[1].prob = x;
                pred[1].label = i + 1;

                if (x > pred[0].prob)
                {
                    pred[1].prob = pred[0].prob;
                    pred[1].label = pred[0].label;
                    pred[0].prob = x;
                    pred[0].label = i + 1;
                }
            }
        }
    }

    output.close(); // Closing files
    return pred;
}
