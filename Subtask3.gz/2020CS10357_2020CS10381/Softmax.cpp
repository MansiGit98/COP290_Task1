#include <fstream>
#include <iostream>
#include <math.h>
#include "audio.hpp"
using namespace std;

void runSOFTMAX(string inputFile, string outputFile, int size)
{
    ifstream matrix;
    matrix.open(inputFile);

    if (!matrix)
    {
        cerr << "Error: Input matrix file could not be opened" << endl;
        exit(1);
    }

    fstream file;
    file.open(outputFile, ios::out);

    if (!file)
    {
        cerr << "Error in creating file" << endl;
        exit(1);
    }

    string str;

    float sum = 0.0;
    float* arr= new float[size]; // array to store elements of matrix

    for (int r = 0; r < size; r++)
    {
        getline(matrix, str);
        arr[r] = exp(stof(str));
        sum += arr[r]; // Storing float values given in input
    }
    for (int c = 0; c < size; c++)
    {
        file << arr[c] / sum << endl;
    }
    matrix.close();
    file.close();
    return;
}
